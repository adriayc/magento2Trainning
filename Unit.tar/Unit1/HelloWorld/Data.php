<?php
/**
 * Created by PhpStorm.
 * User: adrian
 * Date: 2/2/18
 * Time: 4:47 PM
 */

namespace Unit1\HelloWorld;


use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{

}